package ca.arshjudge.telecom.api;

import ca.arshjudge.telecom.api.dto.*;
import ca.arshjudge.telecom.domain.SubscriptionStatus;
import ca.arshjudge.telecom.service.SubscriptionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/subscriptions")
public class SubscriptionController {
    private final SubscriptionService service;
    public SubscriptionController(SubscriptionService service) { this.service = service; }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public SubscriptionResponse create(@Valid @RequestBody SubscriptionRequest request) { return service.create(request); }
    @GetMapping public List<SubscriptionResponse> list(@RequestParam(required=false) Long customerId) { return service.list(customerId); }
    @PatchMapping("/{id}/status")
    public SubscriptionResponse changeStatus(@PathVariable Long id, @RequestParam SubscriptionStatus status) { return service.changeStatus(id, status); }
}
