package ca.arshjudge.telecom.api;

import ca.arshjudge.telecom.api.dto.*;
import ca.arshjudge.telecom.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {
    private final OrderService service;
    public OrderController(OrderService service) { this.service = service; }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public OrderResponse create(@Valid @RequestBody OrderRequest request) { return service.create(request); }
    @GetMapping public List<OrderResponse> list(@RequestParam(required=false) Long customerId) { return service.list(customerId); }
    @PatchMapping("/{id}/status")
    public OrderResponse changeStatus(@PathVariable Long id, @Valid @RequestBody OrderStatusRequest request) {
        return service.changeStatus(id, request.status());
    }
}
