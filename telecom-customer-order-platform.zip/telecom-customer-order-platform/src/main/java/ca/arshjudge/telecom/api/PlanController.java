package ca.arshjudge.telecom.api;

import ca.arshjudge.telecom.api.dto.*;
import ca.arshjudge.telecom.domain.Plan;
import ca.arshjudge.telecom.service.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/plans")
public class PlanController {
    private final PlanService service;
    public PlanController(PlanService service) { this.service = service; }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public PlanResponse create(@Valid @RequestBody PlanRequest request) { return service.create(request); }
    @GetMapping public List<PlanResponse> list(@RequestParam(defaultValue="true") boolean activeOnly) { return service.list(activeOnly); }
    @PutMapping("/{id}") public PlanResponse update(@PathVariable Long id, @Valid @RequestBody PlanRequest request, @RequestParam(defaultValue="true") boolean active) {
        return service.update(id, request, active);
    }
}
