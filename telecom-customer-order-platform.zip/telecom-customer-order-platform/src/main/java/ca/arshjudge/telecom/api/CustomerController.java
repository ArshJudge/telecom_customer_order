package ca.arshjudge.telecom.api;

import ca.arshjudge.telecom.api.dto.*;
import ca.arshjudge.telecom.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {
    private final CustomerService service;
    public CustomerController(CustomerService service) { this.service = service; }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public CustomerResponse create(@Valid @RequestBody CustomerRequest request) { return service.create(request); }
    @GetMapping public Page<CustomerResponse> list(@RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="20") int size) {
        if (page < 0 || size < 1 || size > 100) throw new IllegalArgumentException("page must be >= 0 and size must be between 1 and 100");
        return service.list(page, size);
    }
    @GetMapping("/{id}") public CustomerResponse get(@PathVariable Long id) { return service.get(id); }
    @PutMapping("/{id}") public CustomerResponse update(@PathVariable Long id, @Valid @RequestBody CustomerRequest request) { return service.update(id, request); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id) { service.delete(id); }
}
